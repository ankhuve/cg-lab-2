#include "MyQuat.h"

using namespace MyMathLab;

///YOUR CODE HERE