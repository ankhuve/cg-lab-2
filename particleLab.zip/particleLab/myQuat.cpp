#include "MyQuat.h"

///YOUR CODE HERE